#!/bin/sh
# g++ -o main main.cpp -g -std=c++11 -I /usr/local/include/eigen3/ -Iinclude -Wall
g++ -o main main.cpp -O3 -Ofast -std=c++11 -I /usr/local/include/eigen3/ -Iinclude
